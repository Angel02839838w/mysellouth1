const decodeHtmlEntities = s => s.replace(/&#(\d+);/g,(_,d)=>String.fromCharCode(d)).replace(/&quot;|&apos;|&amp;|&lt;|&gt;/g, m=>({ "&quot;":"\"","&apos;":"'","&amp;":"&","&lt;":"<","&gt;":">" }[m]));

document.addEventListener('alpine:init', () => {
  Alpine.data('app', () => ({
    appScheme: {
      mode: 'dark',
      explicit: false,

      init() {
        let stored = null;
        try { stored = localStorage.getItem('scheme'); } catch (e) {}
        this.explicit = stored === 'light' || stored === 'dark';
        this.mode = document.documentElement.getAttribute('data-scheme') || 'dark';

        window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', (e) => {
          if (!this.explicit && (window.themeConfig?.schemeDefault || 'system') === 'system') {
            this.apply(e.matches ? 'dark' : 'light', false);
          }
        });
      },

      apply(mode, persist = true) {
        this.mode = mode;
        document.documentElement.setAttribute('data-scheme', mode);
        const tc = document.querySelector('meta[data-sa-tc]');
        if (tc) tc.setAttribute('content', tc.getAttribute(`data-sa-tc-${mode}`));
        if (persist) {
          this.explicit = true;
          try { localStorage.setItem('scheme', mode); } catch (e) {}
        }
      },

      toggle() {
        this.apply(this.mode === 'dark' ? 'light' : 'dark');
      },

      get isDark() {
        return this.mode === 'dark';
      },
    },

    appCurrency: {
      ratesUsd: window.currencyRatesUsd || {},
      currency: window.defaultCurrency || 'usd',

      convert(price, fromCurrency, toCurrency = this.currency) {
        const fromRate = this.ratesUsd[fromCurrency.toLowerCase()];
        const toRate = this.ratesUsd[toCurrency.toLowerCase()];

        if (fromCurrency === toCurrency) {
          return price;
        }
        
        if (!fromRate || !toRate) {
          console.error('Invalid currency conversion', { fromCurrency, toCurrency, rates: this.ratesUsd });
          return price;
        }

        return (price / fromRate) * toRate;
      },
      
      format(price, fromCurrency, locale = 'en-US') {
        const toCurrency = this.currency || fromCurrency;
        const convertedPrice = this.convert(price, fromCurrency, toCurrency);

        return new Intl.NumberFormat(locale, {
          style: 'currency',
          currency: toCurrency,
          currencyDisplay: 'symbol',
        }).format(convertedPrice);
      },

      set(code) {
        code = String(code).toLowerCase();

        if (!this.ratesUsd[code]) {
          console.error('Invalid currency', code, this.ratesUsd);
          return;
        }

        this.currency = code;
        localStorage.setItem('currency', code);
      },

      init() {
        const storedDefault = localStorage.getItem('defaultCurrency');
        if (storedDefault && storedDefault !== window.defaultCurrency) {
          localStorage.removeItem('currency');
        }
        localStorage.setItem('defaultCurrency', window.defaultCurrency);

        const storedCurrency = localStorage.getItem('currency')?.toLowerCase();

        if (storedCurrency && this.ratesUsd[storedCurrency]) {
          this.currency = storedCurrency;
        } else if (storedCurrency) {
          console.error('Invalid currency in local storage', storedCurrency, this.ratesUsd);
        }
      },
    },

    appCart: {
      items: [],
      
      updateLocalStorage: function () {
        localStorage.setItem('cart', JSON.stringify(this.items));
      },
      
      set: function (items) {
        this.items = items;
        this.updateLocalStorage();
      },
      
      add: function (productId, variantId, quantity, parentVariantId = null) {
        const item = this.items.find((item) => item.variantId === variantId && (!item.parentVariantId || item.parentVariantId === parentVariantId));

        if (item) {
          item.quantity += quantity;
        } else {
          this.items.push({ productId, variantId, quantity, parentVariantId });
        }

        this.updateLocalStorage();
      },
      
      remove: function (variantId, parentVariantId = null) {
        this.items = this.items.filter((item) => item.variantId !== variantId || (item.parentVariantId && item.parentVariantId !== parentVariantId));
        this.updateLocalStorage();
      },
      
      editQuantity: function (variantId, quantity) {
        const item = this.items.find((item) => item.variantId === variantId);
        item.quantity = quantity;
        this.updateLocalStorage();
      },

      isInCart: function (variantId, parentVariantId = null) {
        return this.items.some((item) => item.variantId === variantId && (!item.parentVariantId || item.parentVariantId === parentVariantId));
      },
      
      get countWithQuantities() {
        return this.items.reduce((acc, item) => {
          if (!item.parentVariantId) {
            return acc + item.quantity;
          }

          return acc;
        }, 0);
      },
      
      init: function () {
        if (localStorage.getItem('cart')) {
          try {
            this.items = JSON.parse(localStorage.getItem('cart'));
            if (!Array.isArray(this.items)) {
              this.items = [];
            }
          } catch (error) {
            console.error('Error parsing cart from local storage', error);
            this.items = [];
          }
        }
      }
    },

    // Hydrated cart view shared by the cart panel (drawer/modal/sheet) and the cart page.
    appCartUi: {
      isOpen: false,
      loading: false,
      submitting: false,
      error: null,
      messages: [],
      fullCart: [],
      quantityDeals: [],
      bundleOffers: [],

      get mode() {
        return window.themeConfig?.cartMode || 'drawer-right';
      },

      open() {
        if (this.mode === 'page') {
          window.location.href = '/cart';
          return;
        }

        this.isOpen = true;
        document.body.style.overflow = 'hidden';
        this.hydrate();
      },

      close() {
        this.isOpen = false;
        document.body.style.removeProperty('overflow');
      },

      async hydrate() {
        const root = window.alpineApp;

        if (!root.appCart.items.length) {
          this.fullCart = [];
          this.messages = [];
          this.quantityDeals = [];
          this.bundleOffers = [];
          return;
        }

        this.loading = this.fullCart.length === 0;
        this.error = null;

        try {
          const url = new URL(`${window.apiBaseUrl}/v1/cart`);
          url.searchParams.append('shopId', String(window.shopId));
          url.searchParams.append('cart', JSON.stringify(root.appCart.items));

          const response = await fetch(url, {
            method: 'GET',
            headers: { Accept: 'application/json', 'Content-Type': 'application/json' },
          });
          const responseData = await response.json();

          if (!response.ok || responseData.success === false) {
            this.error = responseData?.message || 'Could not load your cart.';
            return;
          }

          this.fullCart = Array.isArray(responseData.fullCart) ? responseData.fullCart : [];
          this.messages = responseData.messages || [];
          this.quantityDeals = responseData.quantity_deals || [];
          this.bundleOffers = responseData.bundle_offers || [];

          if (responseData.cart) {
            root.appCart.set(responseData.cart);
          }
        } catch (error) {
          console.error(error);
          this.error = 'Could not load your cart.';
        } finally {
          this.loading = false;
        }
      },

      removeItem(index) {
        const root = window.alpineApp;
        const item = this.fullCart[index];
        if (!item) return;

        const variantId = item.variantId ?? item.variant.id;

        if (item.addons) {
          item.addons.forEach((addon) => {
            root.appCart.remove(addon.variantId ?? addon.variant.id, variantId);
          });
        }

        root.appCart.remove(variantId, item.parentVariantId || null);
        this.fullCart.splice(index, 1);
      },

      changeQuantity(index, quantity) {
        const root = window.alpineApp;
        const item = this.fullCart[index];
        if (!item) return;

        const min = item.variant.quantity_min || 1;
        const max = item.variant.quantity_max || 10000;
        const stockMax = item.product.hide_stock_count || item.variant.stock === -1
          ? max
          : Math.min(max, item.variant.stock);
        const newQuantity = Math.min(Math.max(min, quantity), stockMax);

        this.fullCart[index].quantity = newQuantity;
        root.appCart.editQuantity(item.variantId ?? item.variant.id, newQuantity);
      },

      clear() {
        window.alpineApp.appCart.set([]);
        this.fullCart = [];
        this.messages = [];
        this.quantityDeals = [];
        this.bundleOffers = [];
      },

      // Highest volume-discount tier the item's quantity qualifies for (or null).
      getAppliedVolumeDiscount(item) {
        if (!item.variant.volume_discounts) return null;
        const tiers = [...item.variant.volume_discounts].sort((a, b) => b.quantity - a.quantity);
        for (const tier of tiers) {
          if (item.quantity >= parseInt(tier.quantity)) return tier;
        }
        return null;
      },

      getItemUnitPrice(item) {
        const discount = this.getAppliedVolumeDiscount(item);
        if (discount) {
          return item.variant.price * (1 - parseFloat(discount.percentage) / 100);
        }
        return item.variant.price;
      },

      getItemBaseTotal(item) {
        const addons = item.addons ? item.addons.reduce((sum, addon) => sum + addon.variant.price, 0) : 0;
        return item.quantity * item.variant.price + addons;
      },

      getItemTotal(item) {
        const addons = item.addons ? item.addons.reduce((sum, addon) => sum + addon.variant.price, 0) : 0;
        return item.quantity * this.getItemUnitPrice(item) + addons;
      },

      getQuantityDealDiscount(deal) {
        const bundleSize = deal.buy_quantity + deal.discounted_quantity;
        let totalQty;
        if (deal.variant_id !== null) {
          const item = this.fullCart.find((i) => (i.variantId ?? i.variant.id) === deal.variant_id);
          totalQty = item ? item.quantity : 0;
        } else {
          totalQty = this.fullCart.reduce((s, i) => s + i.quantity, 0);
        }
        let applications = Math.floor(totalQty / bundleSize);
        if (deal.max_uses_per_cart) applications = Math.min(applications, deal.max_uses_per_cart);
        if (applications === 0) return 0;

        let unitPrice;
        if (deal.variant_id !== null) {
          const item = this.fullCart.find((i) => (i.variantId ?? i.variant.id) === deal.variant_id);
          unitPrice = item ? this.getItemUnitPrice(item) : 0;
        } else {
          const prices = this.fullCart.map((i) => this.getItemUnitPrice(i)).sort((a, b) => a - b);
          unitPrice = prices[0] || 0;
        }
        return applications * deal.discounted_quantity * unitPrice * (deal.percentage / 100);
      },

      getBundleDiscount(offer) {
        if (!offer.active || offer.applications === 0) return 0;
        if (offer.type === 'percentage') {
          let bundleItemsTotal = 0;
          for (const bundleItem of offer.items) {
            const cartItem = bundleItem.type === 'variant'
              ? this.fullCart.find((i) => (i.variantId ?? i.variant.id) === bundleItem.id)
              : this.fullCart.find((i) => (i.productId ?? i.product.id) === bundleItem.id);
            if (cartItem) {
              bundleItemsTotal += this.getItemUnitPrice(cartItem) * (bundleItem.quantity || 1);
            }
          }
          return offer.applications * bundleItemsTotal * (offer.discount / 100);
        }
        return offer.applications * offer.discount;
      },

      get discountTotal() {
        const deals = this.quantityDeals.reduce((s, d) => s + this.getQuantityDealDiscount(d), 0);
        const bundles = this.bundleOffers.reduce((s, o) => s + this.getBundleDiscount(o), 0);
        return deals + bundles;
      },

      get subtotal() {
        return this.fullCart.reduce((acc, item) => acc + this.getItemTotal(item), 0);
      },

      get total() {
        return Math.max(0, this.subtotal - this.discountTotal);
      },

      get currency() {
        return this.fullCart.length > 0 ? this.fullCart[0].product.currency : window.defaultCurrency || 'USD';
      },

      get count() {
        if (this.fullCart.length > 0) {
          return this.fullCart.reduce((acc, item) => acc + item.quantity, 0);
        }
        return window.alpineApp ? window.alpineApp.appCart.countWithQuantities : 0;
      },

      async checkout(captcha = null) {
        if (this.submitting || this.fullCart.length === 0) return;

        this.submitting = true;
        this.error = null;

        const formData = {
          cart: window.alpineApp.appCart.items,
          currency: window.alpineApp.appCurrency.currency,
          shopId: String(window.shopId),
          source: 'storefront',
          attribution: window.getAttribution?.() ?? undefined,
        };

        if (window.shopCustomer?.email) {
          formData.email = window.shopCustomer.email;
        }

        if (captcha?.altcha) {
          formData.altcha = captcha.altcha;
        } else if (captcha?.recaptchaToken) {
          formData.recaptchaToken = captcha.recaptchaToken;
        }

        try {
          const response = await fetch(`${window.apiBaseUrl}/v1/checkout`, {
            method: 'POST',
            headers: { Accept: 'application/json', 'Content-Type': 'application/json' },
            body: JSON.stringify(formData),
          });
          const responseData = await response.json();

          if (responseData.url) {
            localStorage.setItem('cart', JSON.stringify([]));
            window.location.href = responseData.url;
            return;
          }

          // Captcha-protected shops verify at the cart page, which renders the widget.
          if (response.status === 422 && !captcha && window.location.pathname !== '/cart') {
            window.location.href = '/cart';
            return;
          }

          this.error = responseData?.message || 'Checkout failed. Please try again.';
        } catch (error) {
          console.error(error);
          this.error = 'Unexpected error. Please try again.';
        } finally {
          this.submitting = false;
        }
      },

      onAdded(detail) {
        const behavior = window.themeConfig?.addToCartBehavior || 'open-cart';

        if (behavior === 'open-cart' && this.mode !== 'page') {
          this.open();
        } else if (behavior === 'toast' || (behavior === 'open-cart' && this.mode === 'page')) {
          window.alpineApp.appToasts.push(detail?.message || 'Added to cart');
        }
      },
    },

    appToasts: {
      items: [],
      nextId: 1,

      push(message, type = 'success', timeout = 3500) {
        const id = this.nextId++;
        this.items.push({ id, message, type });
        setTimeout(() => this.dismiss(id), timeout);
      },

      dismiss(id) {
        this.items = this.items.filter((toast) => toast.id !== id);
      },
    },

    appCustomer: {
      modalIsOpen: false,
      modalStep: 1,
      modalEmail: '',
      modalOtpDigits: Array(6).fill(''),
      modalEmailError: '',
      modalOtpError: '',
      modalLoading: false,
      altchaPayload: null,
      afterLoginPath: '/customer/dashboard',
      modalUsePassword: false,
      modalPassword: '',
      modalTfaCode: '',
      modalTfaError: '',
      modalDiscordCode: null,
      discordError: '',
      discordPopup: null,
      discordPoll: null,
      discordListening: false,

      addAltchaEventListener: function () {
        window.alpineApp.$refs['appCustomer.altcha'].addEventListener('statechange', (event) => {
          if (event.detail.state === 'verifying') {
            this.buyNowDisabled = true;
          } else if (event.detail.state === 'verified') {
            this.buyNowDisabled = false;
            this.altchaPayload = event.detail.payload;
          }
        });
      },
      
      modalOpen() {
        this.modalIsOpen = true;
        this.modalStep = 1;
        document.body.style.overflow = 'hidden';

        window.alpineApp.$nextTick(() => {
          window.alpineApp.$refs['appCustomer.modalEmailInput'].focus();
        });
      },
  
      modalClose() {
        this.modalIsOpen = false;

        clearInterval(this.discordPoll);
        this.discordPoll = null;
        this.discordPopup = null;

        setTimeout(() => {
          this.modalEmail = '';
          this.otp = '';
          this.modalStep = 1;
          this.modalEmailError = '';
          this.modalOtpError = '';
          this.modalUsePassword = false;
          this.modalPassword = '';
          this.modalTfaCode = '';
          this.modalTfaError = '';
          this.modalDiscordCode = null;
          this.discordError = '';
        }, 300); // Transition

        document.body.style.overflow = 'auto';
      },

      // Password login skips the captcha/OTP request entirely.
      modalUsePasswordLogin() {
        if (!this.modalEmail) {
          this.modalEmailError = 'Enter your e-mail address first.';
          return;
        }

        this.modalEmailError = '';
        this.modalUsePassword = true;
        this.modalStep = 2;
      },

      modalUseOtpLogin() {
        this.modalUsePassword = false;
        this.modalPassword = '';
        this.modalStep = 1;
      },

      async modalRequestOtp() {
        this.modalEmailError = '';
        this.modalOtpError = '';
        this.modalLoading = true;
  
        try {
          const response = await fetch(`${window.apiBaseUrl}/v1/customer-dashboard/request-otp`, {
            method: 'POST',
            headers: {
              'Accept': 'application/json',
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              email: this.modalEmail,
              shop_id: window.shopId,
              altcha: this.altchaPayload
            })
          });
  
          const data = await response.json();
  
          if (data.success) {
            this.modalStep = 2;
            setTimeout(() => {
              window.alpineApp.$refs['appCustomer.modalOtpInputs[0]'].focus();
            }, 10);
          } else {
            this.modalEmailError = data?.message || 'Failed to send OTP. Please try again.';
          }
        } catch (error) {
          this.modalEmailError = 'Network error. Please try again.';
        } finally {
          this.modalLoading = false;
        }
      },

      modalOtpHandleInput(index) {
        const input = this.modalOtpDigits[index];
        
        if (input === '' || /^\d$/.test(input)) {
          if (input && index < this.modalOtpDigits.length - 1) {
            window.alpineApp.$refs[`appCustomer.modalOtpInputs[${index + 1}]`].focus();
          }
        } else {
          this.modalOtpDigits[index] = '';
        }
      },
  
      modalOtpHandleKeyDown(index, event) {
        if (event.key === 'Backspace' && !this.modalOtpDigits[index] && index > 0) {
          window.alpineApp.$refs[`appCustomer.modalOtpInputs[${index - 1}]`].focus();
        }
      },
  
      modalOtpHandlePaste(event) {
        event.preventDefault();
        const pastedData = event.clipboardData.getData('text');

        if (/^\d+$/.test(pastedData)) {
          const newOtp = pastedData.split('').slice(0, this.modalOtpDigits.length);
          
          newOtp.forEach((digit, index) => {
            this.modalOtpDigits[index] = digit;
          });
  
          for (let i = newOtp.length; i < this.modalOtpDigits.length; i++) {
            this.modalOtpDigits[i] = '';
          }
  
          window.alpineApp.$refs[`appCustomer.modalOtpInputs[${this.modalOtpDigits.length - 1}]`].focus();
        }
      },
  
      // Popup flow: the callback posts a one-time handoff code that loginWithDiscordCode() trades for a session.
      loginWithDiscord() {
        this.discordError = '';
        this.modalEmailError = '';

        const popup = window.open(
          '/discord/login-redirect?intent=login&origin=' + encodeURIComponent(window.location.origin),
          'sa_discord_login',
          'width=520,height=760'
        );

        if (!popup) {
          this.discordError = 'blocked';
          return;
        }

        this.discordListen();
        this.discordPopup = popup;
        this.modalLoading = true;

        clearInterval(this.discordPoll);
        this.discordPoll = setInterval(() => {
          if (!this.discordPopup || !this.discordPopup.closed) {
            return;
          }

          clearInterval(this.discordPoll);
          this.discordPoll = null;
          this.discordPopup = null;

          if (!this.modalDiscordCode) {
            this.modalLoading = false;
          }
        }, 500);
      },

      discordListen() {
        if (this.discordListening) {
          return;
        }

        this.discordListening = true;
        window.addEventListener('message', (event) => this.onDiscordMessage(event));
      },

      onDiscordMessage(event) {
        if (event.origin !== window.location.origin || !this.discordPopup || event.source !== this.discordPopup) {
          return;
        }

        const data = event.data;

        if (!data || data.type !== 'DISCORD_AUTH' || data.intent !== 'login') {
          return;
        }

        clearInterval(this.discordPoll);
        this.discordPoll = null;
        this.discordPopup = null;

        if (data.error || !data.code) {
          this.modalLoading = false;
          this.discordError = data.error === 'access_denied' ? '' : 'failed';
          return;
        }

        this.modalDiscordCode = data.code;
        this.loginWithDiscordCode();
      },

      async loginWithDiscordCode() {
        this.discordError = '';
        this.modalOtpError = '';
        this.modalTfaError = '';
        this.modalLoading = true;

        try {
          const formData = {
            shop_id: window.shopId,
            code: this.modalDiscordCode,
          };

          if (this.modalTfaCode) {
            formData.tfa_code = this.modalTfaCode;
          }

          try {
            const storedAffiliate = JSON.parse(localStorage.getItem('affiliate'));
            if (storedAffiliate?.code && (!storedAffiliate.expires || Date.now() <= storedAffiliate.expires)) {
              formData.affiliate = storedAffiliate.code;
            }
          } catch {}

          const response = await fetch(`${window.apiBaseUrl}/v1/customer-dashboard/login/discord`, {
            method: 'POST',
            headers: {
              'Accept': 'application/json',
              'Content-Type': 'application/json',
            },
            body: JSON.stringify(formData)
          });

          const data = await response.json();

          if (data.token) {
            Cookies.set('shop_customer_token', data.token, { expires: 30, path: '/' });
            window.location.href = this.afterLoginPath || '/customer/dashboard';
          } else if (data.requires_tfa) {
            this.modalStep = 3;
          } else if (this.modalStep === 3 && response.status === 401 && /two-factor/i.test(data?.message || '')) {
            this.modalTfaError = data.message;
          } else {
            // The handoff is gone (expired, refused or too many wrong codes): start over.
            this.modalDiscordCode = null;
            this.modalTfaCode = '';
            this.modalStep = 1;
            this.discordError = data?.message || 'failed';
          }
        } catch (error) {
          console.error(error);
          this.discordError = 'failed';
        } finally {
          this.modalLoading = false;
        }
      },

      async modalLogin() {
        if (this.modalDiscordCode) {
          return this.loginWithDiscordCode();
        }

        if (this.modalUsePassword) {
          if (!this.modalPassword) {
            this.modalOtpError = 'Enter your password.';
            return;
          }
        } else {
          const otp = this.modalOtpDigits.join('');

          if (otp.length !== 6) {
            this.modalOtpError = 'Invalid OTP.';
            return;
          }
        }

        this.modalEmailError = '';
        this.modalOtpError = '';
        this.modalTfaError = '';
        this.modalLoading = true;

        try {
          const formData = {
            email: this.modalEmail,
            shop_id: window.shopId,
          };

          if (this.modalUsePassword) {
            formData.password = this.modalPassword;
          } else {
            formData.otp = this.modalOtpDigits.join('');
          }

          // 2FA step resubmits the same credentials with the code.
          if (this.modalTfaCode) {
            formData.tfa_code = this.modalTfaCode;
          }

          try {
            const storedAffiliate = JSON.parse(localStorage.getItem('affiliate'));
            if (storedAffiliate?.code && (!storedAffiliate.expires || Date.now() <= storedAffiliate.expires)) {
              formData.affiliate = storedAffiliate.code;
            }
          } catch {}

          const response = await fetch(`${window.apiBaseUrl}/v1/customer-dashboard/login`, {
            method: 'POST',
            headers: {
              'Accept': 'application/json',
              'Content-Type': 'application/json',
            },
            body: JSON.stringify(formData)
          });

          const data = await response.json();

          if (data.token) {
            Cookies.set('shop_customer_token', data.token, { expires: 30, path: '/' });
            window.location.href = this.afterLoginPath || '/customer/dashboard';
          } else if (data.requires_tfa) {
            this.modalStep = 3;
          } else if (this.modalStep === 3) {
            this.modalTfaError = data?.message || 'Invalid two-factor authentication code.';
          } else {
            this.modalOtpError = data?.message || 'Invalid credentials.';
          }
        } catch (error) {
          console.error(error);
          if (this.modalStep === 3) {
            this.modalTfaError = 'Invalid credentials.';
          } else {
            this.modalOtpError = 'Invalid credentials.';
          }
        } finally {
          this.modalLoading = false;
        }
      },

      loginOrRedirect() {
        if (window.shopCustomer) {
          window.location.href = '/customer/dashboard';
        } else {
          this.modalOpen();
        }
      },

      async logout() {
        const token = Cookies.get('shop_customer_token');

        if (!token) {
          return;
        }

        try {
          fetch(`${window.apiBaseUrl}/v1/customer-dashboard/logout`, {
            method: 'POST',
            headers: {
              'Accept': 'application/json',
              'Authorization': `Bearer ${token}`,
              'Content-Type': 'application/json',
            }
          });
        } catch (error) {
          console.error('Logout error', error);
        }

        Cookies.remove('shop_customer_token');
        window.location.href = '/';
      },

      deleteModalIsOpen: false,
      deleteModalLoading: false,

      openDeleteModal() {
        this.deleteModalIsOpen = true;
        document.body.style.overflow = 'hidden';
      },

      closeDeleteModal() {
        this.deleteModalIsOpen = false;
        document.body.style.overflow = 'auto';
      },

      loggingOutOtherSessions: false,

      async logoutOtherSessions() {
        const token = Cookies.get('shop_customer_token');

        if (!token) {
          return;
        }

        this.loggingOutOtherSessions = true;

        try {
          const response = await fetch(`${window.apiBaseUrl}/v1/customer-dashboard/logout-other-sessions`, {
            method: 'POST',
            headers: {
              'Accept': 'application/json',
              'Authorization': `Bearer ${token}`,
              'Content-Type': 'application/json',
            }
          });

          const data = await response.json();

          if (data.success) {
            window.location.reload();
          } else {
            console.error('Logout all devices error', data);
            alert(data.message || 'Failed to logout all devices. Please try again.');
          }
        } catch (error) {
          console.error('Logout other sessions error', error);
          alert('Network error. Please try again.');
        } finally {
          this.loggingOutOtherSessions = false;
        }
      },

      async deleteAccount() {
        const token = Cookies.get('shop_customer_token');

        if (!token) {
          return;
        }

        this.deleteModalLoading = true;
        
        try {
          const response = await fetch(`${window.apiBaseUrl}/v1/customer-dashboard/delete-account`, {
            method: 'POST',
            headers: {
              'Accept': 'application/json',
              'Authorization': `Bearer ${token}`,
              'Content-Type': 'application/json',
            },
          });

          const data = await response.json();
          
          if (data.success) {
            Cookies.remove('shop_customer_token');
            window.location.href = '/';
          } else {
            console.error('Delete account error', data);
            alert(data.message || 'Failed to delete account. Please try again.');
          }
        } catch (error) {
          console.error('Delete account error', error);
          alert('Network error. Please try again.');
        } finally {
          this.deleteModalLoading = false;
          this.closeDeleteModal();
        }
      },

      init() {
        if (window.alpineApp.$refs['appCustomer.altcha']) {
          this.addAltchaEventListener();
        }
        
        if (window.alpineApp.$refs['appCustomer.modalOtpInputs[0]']) {
          window.alpineApp.$refs['appCustomer.modalOtpInputs[0]'].addEventListener('paste', (event) => this.modalOtpHandlePaste(event));
        }

        const urlParams = new URLSearchParams(window.location.search);
        
        if (urlParams.get('login') === '1') {
          this.modalOpen();

          const back = urlParams.get('back');
          if (['dashboard', 'invoices', 'subscriptions', 'tickets', 'balance', 'reseller', 'affiliate'].includes(back)) {
            urlParams.delete('login');
            urlParams.delete('back');
            this.afterLoginPath = `/customer/${back}?${urlParams.toString()}`;
          }
        }

        const affiliate = urlParams.get('a') || urlParams.get('affiliate');
        if (affiliate) {
          const saveAffiliate = () => {
            const days = window.affiliateAttributionWindowDays || 30;
            localStorage.setItem('affiliate', JSON.stringify({
              code: affiliate,
              expires: Date.now() + days * 24 * 60 * 60 * 1000
            }));
          };
          if (!window.saConsent || window.saConsent.has('marketing')) {
            saveAffiliate();
          } else {
            const stop = window.saConsent.onChange(state => {
              if (state.marketing) { stop(); saveAffiliate(); }
            });
          }
        }
      }
    },

    appTickets: {
      modalIsOpen: false,
      invoiceId: '',
      subject: '',
      message: '',
      error: '',
      loading: false,
      files: [],
      MAX_FILES: 5,
      MAX_BYTES: 5 * 1024 * 1024,
      ACCEPT: ['image/jpeg', 'image/png', 'image/webp', 'image/gif', 'image/avif'],

      addFiles(list) {
        for (const file of Array.from(list || [])) {
          if (!this.ACCEPT.includes(file.type)) {
            this.error = 'Only JPG, PNG, WEBP, GIF or AVIF images are allowed.';
            continue;
          }

          if (file.size > this.MAX_BYTES) {
            this.error = `${file.name} is larger than 5 MB.`;
            continue;
          }

          if (this.files.length >= this.MAX_FILES) {
            this.error = `You can attach up to ${this.MAX_FILES} images.`;
            break;
          }

          this.files.push({ id: Date.now() + '-' + this.files.length, file, url: URL.createObjectURL(file) });
        }
      },

      removeFile(id) {
        const entry = this.files.find((f) => f.id === id);
        if (entry) {
          URL.revokeObjectURL(entry.url);
        }
        this.files = this.files.filter((f) => f.id !== id);
      },

      clearFiles() {
        this.files.forEach((f) => URL.revokeObjectURL(f.url));
        this.files = [];
      },

      modalOpen(invoiceId = '') {
        this.modalIsOpen = true;
        this.invoiceId = invoiceId;
        document.body.style.overflow = 'hidden';

        window.alpineApp.$nextTick(() => {
          window.alpineApp.$refs['appTickets.subjectInput'].focus();
        });
      },

      modalClose() {
        this.modalIsOpen = false;
        
        setTimeout(() => {
          this.invoiceId = '';
          this.subject = '';
          this.message = '';
          this.error = '';
          this.loading = false;
          this.clearFiles();
        }, 300);

        document.body.style.overflow = 'auto';
      },

      async submitTicket() {
        const token = Cookies.get('shop_customer_token');

        if (!token) {
          return;
        }

        if (!this.message.trim() && !this.files.length) {
          this.error = 'Write a message or attach an image.';
          return;
        }

        this.error = '';
        this.loading = true;

        const headers = {
          'Accept': 'application/json',
          'Authorization': `Bearer ${token}`,
        };
        let body;

        if (this.files.length) {
          body = new FormData();
          body.append('invoice_id', this.invoiceId);
          body.append('subject', this.subject);
          if (this.message.trim()) {
            body.append('content', this.message);
          }
          this.files.forEach((f) => body.append('images[]', f.file));
        } else {
          headers['Content-Type'] = 'application/json';
          body = JSON.stringify({
            invoice_id: this.invoiceId,
            subject: this.subject,
            content: this.message
          });
        }

        try {
          const response = await fetch(`${window.apiBaseUrl}/v1/customer-dashboard/tickets`, {
            method: 'POST',
            headers,
            body
          });

          const data = await response.json();

          if (data.success) {
            this.modalClose();
            window.location.href = `/customer/tickets/${data?.ticket?.id}`;
          } else {
            this.error = data?.message || 'Failed to create ticket. Please try again.';
          }
        } catch (error) {
          this.error = 'Network error. Please try again.';
          console.error('Ticket creation error:', error);
        } finally {
          this.loading = false;
        }
      },

      init() {
        const urlParams = new URLSearchParams(window.location.search);
        const ticketInvoiceId = urlParams.get('ticket-invoice-id');
        if (ticketInvoiceId) {
          this.modalOpen(ticketInvoiceId);
        }
      }
    },

    appAffiliate: {
      modalEditCodeIsOpen: false,
      editCodeValue: '',
      editCodeError: '',
      editCodeLoading: false,

      payoutAmount: '',
      payoutDetails: '',
      payoutError: '',
      payoutLoading: false,

      transferAmount: '',
      transferError: '',
      transferLoading: false,

      modalPayoutIsOpen: false,

      modalPayoutOpen() {
        this.payoutError = '';
        this.modalPayoutIsOpen = true;
        document.body.style.overflow = 'hidden';
      },

      modalPayoutClose() {
        this.modalPayoutIsOpen = false;
        document.body.style.overflow = 'auto';
      },

      async authedPost(path, body) {
        const token = Cookies.get('shop_customer_token');

        if (!token) {
          return { message: 'Not logged in.' };
        }

        const response = await fetch(`${window.apiBaseUrl}/v1/customer-dashboard/affiliate/${path}`, {
          method: 'POST',
          headers: {
            'Accept': 'application/json',
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(body || {})
        });

        return await response.json();
      },

      async requestPayout() {
        this.payoutError = '';
        this.payoutLoading = true;

        try {
          const data = await this.authedPost('payout-request', {
            amount: parseFloat(this.payoutAmount),
            payout_details: this.payoutDetails
          });

          if (data.success) {
            window.location.reload();
          } else {
            this.payoutError = data?.message || 'Failed to request the payout. Please try again.';
          }
        } catch (error) {
          this.payoutError = 'Network error. Please try again.';
          console.error('Affiliate payout request error:', error);
        } finally {
          this.payoutLoading = false;
        }
      },

      async cancelPayout(payoutRequestId) {
        try {
          const data = await this.authedPost(`payout-request/${payoutRequestId}/cancel`);

          if (data.success) {
            window.location.reload();
          } else {
            this.payoutError = data?.message || 'Failed to cancel the payout request.';
          }
        } catch (error) {
          this.payoutError = 'Network error. Please try again.';
          console.error('Affiliate payout cancel error:', error);
        }
      },

      async submitTransfer() {
        this.transferError = '';
        this.transferLoading = true;

        try {
          const data = await this.authedPost('transfer', {
            amount: parseFloat(this.transferAmount)
          });

          if (data.success) {
            window.location.reload();
          } else {
            this.transferError = data?.message || 'Failed to transfer the balance. Please try again.';
          }
        } catch (error) {
          this.transferError = 'Network error. Please try again.';
          console.error('Affiliate transfer error:', error);
        } finally {
          this.transferLoading = false;
        }
      },

      modalEditCodeOpen(initialValue = '') {
        this.editCodeValue = initialValue;
        this.modalEditCodeIsOpen = true;
        document.body.style.overflow = 'hidden';

        window.alpineApp.$nextTick(() => {
          window.alpineApp.$refs['appAffiliate.editCodeInput'].focus();
        });
      },

      modalEditCodeClose() {
        this.modalEditCodeIsOpen = false;
        
        setTimeout(() => {
          this.editCodeValue = '';
          this.error = '';
          this.loading = false;
        }, 300);

        document.body.style.overflow = 'auto';
      },

      async submitEditCode() {
        const token = Cookies.get('shop_customer_token');

        if (!token) {
          return;
        }

        this.editCodeError = '';
        this.editCodeLoading = true;

        try {
          const response = await fetch(`${window.apiBaseUrl}/v1/customer-dashboard/affiliate/edit-code`, {
            method: 'POST',
            headers: {
              'Accept': 'application/json',
              'Authorization': `Bearer ${token}`,
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              affiliate_code: this.editCodeValue
            })
          });

          const data = await response.json();

          if (data.success) {
            this.modalClose();
            window.location.reload();
          } else {
            this.editCodeError = data?.message || 'Failed to update affiliate code. Please try again.';
          }
        } catch (error) {
          this.editCodeError = 'Network error. Please try again.';
          console.error('Affiliate code update error:', error);
        } finally {
          this.editCodeLoading = false;
        }
      }
    },

    appResellerOrder: {
      selection: null,
      messages: {},
      modalIsOpen: false,
      step: 'quote',
      quote: null,
      order: null,
      loading: false,
      paying: false,
      error: '',
      copiedItemId: null,
      balanceOverride: null,

      balance() {
        return this.balanceOverride ?? Number(window.shopCustomer?.balance ?? 0);
      },

      // Always the true amount in the given currency, never converted to the display currency.
      format(amount, currency) {
        return new Intl.NumberFormat('en-US', {
          style: 'currency',
          currency: currency || 'USD',
        }).format(Number(amount ?? 0));
      },

      async request(method, path, body) {
        const token = Cookies.get('shop_customer_token');

        if (!token) {
          throw new Error('signed_out');
        }

        // apiBaseUrl carries a trailing slash in some themes and not others.
        const baseUrl = (window.apiBaseUrl || '').replace(/\/$/, '');

        const response = await fetch(`${baseUrl}/v1/customer-dashboard/reseller/${path}`, {
          method,
          headers: {
            'Accept': 'application/json',
            'Authorization': `Bearer ${token}`,
            ...(body ? { 'Content-Type': 'application/json' } : {}),
          },
          body: body ? JSON.stringify(body) : undefined,
        });

        if (response.status === 401) {
          Cookies.remove('shop_customer_token');
          throw new Error('signed_out');
        }

        const data = await response.json().catch(() => ({}));

        if (!response.ok) {
          const error = new Error(data?.message || this.messages.error || 'Something went wrong. Please try again.');
          error.status = response.status;
          throw error;
        }

        return data;
      },

      openModal() {
        this.modalIsOpen = true;
        document.body.style.overflow = 'hidden';
      },

      closeModal() {
        this.modalIsOpen = false;
        document.body.style.overflow = 'auto';

        setTimeout(() => {
          this.quote = null;
          this.order = null;
          this.step = 'quote';
          this.error = '';
        }, 300); // Transition
      },

      items() {
        return this.selection ? [this.selection] : [];
      },

      async buy(productId, variantId, quantity, messages) {
        if (this.loading) {
          return;
        }

        this.selection = {
          product_id: productId,
          variant_id: variantId,
          quantity: Math.max(1, Math.floor(Number(quantity) || 1)),
        };
        this.messages = messages || {};
        this.error = '';
        this.quote = null;
        this.order = null;
        this.step = 'quote';
        this.loading = true;
        this.openModal();

        try {
          this.quote = await this.request('POST', 'orders/quote', { items: this.items() });
        } catch (error) {
          if (error.message === 'signed_out') {
            window.location.reload();
            return;
          }

          this.error = error.message;
        } finally {
          this.loading = false;
        }
      },

      // The 409 path: keep the modal open, show why, and price the same items again.
      async requote(notice) {
        this.loading = true;
        this.quote = null;

        try {
          this.quote = await this.request('POST', 'orders/quote', { items: this.items() });
          this.error = notice;
        } catch (error) {
          this.error = error.message;
        } finally {
          this.loading = false;
        }
      },

      async confirm() {
        if (!this.quote || !this.quote.can_pay || this.paying) {
          return;
        }

        this.paying = true;
        this.error = '';

        try {
          this.order = await this.request('POST', `orders/${this.quote.unique_id}/pay`, {
            quoted_total_usd: this.quote.price_usd,
          });

          this.step = 'done';
          this.balanceOverride = Math.max(0, Number((this.balance() - Number(this.order.total_usd || 0)).toFixed(2)));

          if (window.shopCustomer) {
            window.shopCustomer.balance = this.balanceOverride;
          }
        } catch (error) {
          if (error.message === 'signed_out') {
            window.location.reload();
            return;
          }

          if (error.status === 409) {
            this.paying = false;
            await this.requote(error.message);
            return;
          }

          if (error.status === 402 && this.quote) {
            this.quote.can_pay = false;
          }

          this.error = error.message;
        } finally {
          this.paying = false;
        }
      },

      hasPending() {
        return !!this.order
          && (this.order.fulfillment_status === 'unfulfilled' || (this.order.items || []).some((item) => item.status !== 'completed'));
      },

      deliveredText(item) {
        return (item.delivered || []).join('\n');
      },

      async copyKeys(item) {
        try {
          await navigator.clipboard.writeText(this.deliveredText(item));
          this.copiedItemId = item.variant_id;
          setTimeout(() => { this.copiedItemId = null; }, 2000);
        } catch (error) {
          console.error('Copy failed:', error);
        }
      },

      downloadKeys(item) {
        const slug = (value) => String(value || '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'keys';
        const blob = new Blob([this.deliveredText(item) + '\n'], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');

        link.href = url;
        link.download = `reseller-${slug(item.product_name)}-${slug(item.variant_name)}.txt`;
        document.body.appendChild(link);
        link.click();
        link.remove();
        setTimeout(() => URL.revokeObjectURL(url), 1000);
      },
    },

    appReseller: {
      applicationAnswer: '',
      applyError: '',
      applyLoading: false,

      apiKey: null,
      apiKeyError: '',
      apiKeyLoading: false,

      webhookSecret: '',
      ddError: '',
      ddLoading: false,
      ddRegenConfirm: false,
      ddRegenLoading: false,

      connectError: '',
      connectLoading: false,
      disconnectConfirm: false,
      disconnectLoading: false,

      apiModalIsOpen: false,
      ddModalIsOpen: false,

      openApiModal() {
        this.apiModalIsOpen = true;
        document.body.style.overflow = 'hidden';
      },

      closeApiModal() {
        this.apiModalIsOpen = false;
        document.body.style.overflow = 'auto';

        setTimeout(() => {
          this.apiKeyError = '';
        }, 300); // Transition
      },

      openDeliveryModal() {
        this.ddModalIsOpen = true;
        document.body.style.overflow = 'hidden';
      },

      closeDeliveryModal() {
        this.ddModalIsOpen = false;
        document.body.style.overflow = 'auto';

        setTimeout(() => {
          this.ddError = '';
          this.ddRegenConfirm = false;
        }, 300); // Transition
      },

      async authedPost(path, body) {
        const token = Cookies.get('shop_customer_token');

        if (!token) {
          return { message: 'Not logged in.' };
        }

        const response = await fetch(`${window.apiBaseUrl}/v1/customer-dashboard/reseller/${path}`, {
          method: 'POST',
          headers: {
            'Accept': 'application/json',
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(body || {})
        });

        return await response.json();
      },

      async apply() {
        this.applyError = '';
        this.applyLoading = true;

        try {
          const data = await this.authedPost('apply', {
            answer: this.applicationAnswer
          });

          if (data.success) {
            window.location.reload();
          } else {
            this.applyError = data?.message || 'Failed to submit the application. Please try again.';
          }
        } catch (error) {
          this.applyError = 'Network error. Please try again.';
          console.error('Reseller apply error:', error);
        } finally {
          this.applyLoading = false;
        }
      },

      async regenerateApiKey() {
        this.apiKeyError = '';
        this.apiKeyLoading = true;

        try {
          const data = await this.authedPost('api-key');

          if (data.api_key) {
            this.apiKey = data.api_key;
          } else {
            this.apiKeyError = data?.message || 'Failed to generate the API key. Please try again.';
          }
        } catch (error) {
          this.apiKeyError = 'Network error. Please try again.';
          console.error('Reseller API key error:', error);
        } finally {
          this.apiKeyLoading = false;
        }
      },

      async saveDynamicDelivery(enabled) {
        this.ddError = '';
        this.ddLoading = true;

        try {
          const body = { enabled: enabled };

          if (this.webhookSecret) {
            body.webhook_secret = this.webhookSecret;
          }

          const data = await this.authedPost('dynamic-delivery', body);

          if (data.success) {
            window.location.reload();
          } else {
            this.ddError = data?.message || 'Failed to update dynamic delivery. Please try again.';
          }
        } catch (error) {
          this.ddError = 'Network error. Please try again.';
          console.error('Reseller dynamic delivery error:', error);
        } finally {
          this.ddLoading = false;
        }
      },

      async regenerateDynamicToken() {
        this.ddError = '';
        this.ddRegenLoading = true;

        try {
          const data = await this.authedPost('dynamic-token/regenerate');

          if (data.success) {
            window.location.reload();
          } else {
            this.ddError = data?.message || 'Failed to regenerate the delivery URLs.';
            this.ddRegenLoading = false;
          }
        } catch (error) {
          this.ddError = 'Network error. Please try again.';
          console.error('Reseller dynamic token error:', error);
          this.ddRegenLoading = false;
        }
      },

      async connectStore() {
        // open synchronously so popup blockers treat it as user-initiated
        const win = window.open('', '_blank');

        this.connectError = '';
        this.connectLoading = true;

        try {
          const data = await this.authedPost('connect-token');

          if (data && data.url) {
            if (win) {
              win.location = data.url;
            } else {
              window.location = data.url;
            }
          } else {
            if (win) win.close();
            this.connectError = data?.message || 'Failed to connect your store. Please try again.';
          }
        } catch (error) {
          if (win) win.close();
          this.connectError = 'Network error. Please try again.';
          console.error('Reseller connect error:', error);
        } finally {
          this.connectLoading = false;
        }
      },

      async disconnectStore() {
        this.connectError = '';
        this.disconnectLoading = true;

        try {
          const data = await this.authedPost('disconnect');

          if (data.success) {
            window.location.reload();
          } else {
            this.connectError = data?.message || 'Failed to disconnect your store.';
            this.disconnectLoading = false;
          }
        } catch (error) {
          this.connectError = 'Network error. Please try again.';
          console.error('Reseller disconnect error:', error);
          this.disconnectLoading = false;
        }
      }
    },

    appSecurity: {
      password: '',
      currentPassword: '',
      tfaCodeForPassword: '',
      passwordError: '',
      passwordSuccess: '',
      passwordLoading: false,
      passwordRemoveConfirm: false,

      tfaSecret: null,
      tfaQrCode: null,
      tfaCode: '',
      tfaRecoveryCodes: null,
      tfaError: '',
      tfaLoading: false,

      passwordModalIsOpen: false,
      tfaModalIsOpen: false,

      discordModalIsOpen: false,
      discordCode: null,
      discordCurrentPassword: '',
      discordTfaCode: '',
      discordError: '',
      discordSuccess: '',
      discordLoading: false,
      discordPopup: null,
      discordPoll: null,
      discordListening: false,

      openPasswordModal() {
        this.passwordModalIsOpen = true;
        document.body.style.overflow = 'hidden';
      },

      closePasswordModal() {
        this.passwordModalIsOpen = false;
        document.body.style.overflow = 'auto';

        setTimeout(() => {
          this.passwordError = '';
          this.passwordSuccess = '';
          this.passwordRemoveConfirm = false;
        }, 300); // Transition
      },

      openTfaModal() {
        this.tfaModalIsOpen = true;
        document.body.style.overflow = 'hidden';
      },

      closeTfaModal() {
        this.tfaModalIsOpen = false;
        document.body.style.overflow = 'auto';

        setTimeout(() => {
          this.tfaError = '';
        }, 300); // Transition
      },

      openDiscordModal() {
        this.discordModalIsOpen = true;
        document.body.style.overflow = 'hidden';
      },

      closeDiscordModal() {
        this.discordModalIsOpen = false;
        document.body.style.overflow = 'auto';

        clearInterval(this.discordPoll);
        this.discordPoll = null;
        this.discordPopup = null;

        setTimeout(() => {
          this.discordError = '';
          this.discordSuccess = '';
          this.discordCurrentPassword = '';
          this.discordTfaCode = '';
        }, 300); // Transition
      },

      discordGuardsMissing() {
        if (window.shopCustomer?.has_password && !this.discordCurrentPassword) {
          this.discordError = 'Enter your current password.';
          return true;
        }

        if (window.shopCustomer?.tfa_enabled && !this.discordTfaCode) {
          this.discordError = 'Enter your two-factor authentication code.';
          return true;
        }

        return false;
      },

      // Popup flow (intent "link"): the posted handoff code is submitted with the modal's password / TFA code.
      connectDiscord() {
        this.discordError = '';

        if (this.discordGuardsMissing()) {
          return;
        }

        if (this.discordCode) {
          this.submitDiscordConnect();
          return;
        }

        const popup = window.open(
          '/discord/login-redirect?intent=link&origin=' + encodeURIComponent(window.location.origin),
          'sa_discord_link',
          'width=520,height=760'
        );

        if (!popup) {
          this.discordError = 'blocked';
          return;
        }

        this.discordListen();
        this.discordPopup = popup;
        this.discordLoading = true;

        clearInterval(this.discordPoll);
        this.discordPoll = setInterval(() => {
          if (!this.discordPopup || !this.discordPopup.closed) {
            return;
          }

          clearInterval(this.discordPoll);
          this.discordPoll = null;
          this.discordPopup = null;

          if (!this.discordCode) {
            this.discordLoading = false;
          }
        }, 500);
      },

      discordListen() {
        if (this.discordListening) {
          return;
        }

        this.discordListening = true;
        window.addEventListener('message', (event) => this.onDiscordMessage(event));
      },

      onDiscordMessage(event) {
        if (event.origin !== window.location.origin || !this.discordPopup || event.source !== this.discordPopup) {
          return;
        }

        const data = event.data;

        if (!data || data.type !== 'DISCORD_AUTH' || data.intent !== 'link') {
          return;
        }

        clearInterval(this.discordPoll);
        this.discordPoll = null;
        this.discordPopup = null;

        if (data.error || !data.code) {
          this.discordLoading = false;
          this.discordError = data.error === 'access_denied' ? '' : 'failed';
          return;
        }

        this.discordCode = data.code;
        this.submitDiscordConnect();
      },

      async submitDiscordConnect() {
        this.discordError = '';
        this.discordLoading = true;

        try {
          const data = await this.authedPost('discord/connect', {
            code: this.discordCode,
            current_password: this.discordCurrentPassword || null,
            tfa_code: this.discordTfaCode || null,
          });

          if (data.success) {
            this.discordCode = null;
            this.discordSuccess = data.message || 'Discord connected.';
            setTimeout(() => window.location.reload(), 1000);
          } else {
            // A guard failure keeps the handoff for a retry; anything else needs a new popup.
            if (!/password|two-factor/i.test(data?.message || '')) {
              this.discordCode = null;
            }

            this.discordError = data?.message || 'failed';
          }
        } catch (error) {
          console.error(error);
          this.discordError = 'failed';
        } finally {
          this.discordLoading = false;
        }
      },

      async disconnectDiscord() {
        this.discordError = '';

        if (this.discordGuardsMissing()) {
          return;
        }

        this.discordLoading = true;

        try {
          const data = await this.authedPost('discord/disconnect', {
            current_password: this.discordCurrentPassword || null,
            tfa_code: this.discordTfaCode || null,
          });

          if (data.success) {
            this.discordSuccess = data.message || 'Discord disconnected.';
            setTimeout(() => window.location.reload(), 1000);
          } else {
            this.discordError = data?.message || 'failed';
          }
        } catch (error) {
          console.error(error);
          this.discordError = 'failed';
        } finally {
          this.discordLoading = false;
        }
      },

      async authedPost(path, body) {
        const token = Cookies.get('shop_customer_token');

        if (!token) {
          return { message: 'Not logged in.' };
        }

        const response = await fetch(`${window.apiBaseUrl}/v1/customer-dashboard/security/${path}`, {
          method: 'POST',
          headers: {
            'Accept': 'application/json',
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(body || {})
        });

        return await response.json();
      },

      async savePassword(requireCurrent = false) {
        this.passwordError = '';
        this.passwordSuccess = '';

        if (requireCurrent && !this.currentPassword) {
          this.passwordError = 'Enter your current password.';
          return;
        }

        if (!this.password || this.password.length < 8) {
          this.passwordError = 'New password must be at least 8 characters.';
          return;
        }

        this.passwordLoading = true;

        try {
          const data = await this.authedPost('password', {
            password: this.password,
            current_password: this.currentPassword || null,
            tfa_code: this.tfaCodeForPassword || null,
          });

          if (data.success) {
            this.password = '';
            this.currentPassword = '';
            this.tfaCodeForPassword = '';
            this.passwordSuccess = 'Password saved. You can now log in with it.';
          } else {
            this.passwordError = data?.message || 'Failed to save the password. Please try again.';
          }
        } catch (error) {
          this.passwordError = 'Network error. Please try again.';
          console.error('Password save error:', error);
        } finally {
          this.passwordLoading = false;
        }
      },

      startRemovePassword() {
        this.passwordError = '';

        if (!this.currentPassword) {
          this.passwordError = 'Enter your current password first.';
          return;
        }

        this.passwordRemoveConfirm = true;
      },

      async removePassword() {
        this.passwordError = '';
        this.passwordSuccess = '';
        this.passwordLoading = true;

        try {
          const data = await this.authedPost('password/remove', {
            current_password: this.currentPassword,
            tfa_code: this.tfaCodeForPassword || null,
          });

          if (data.success) {
            window.location.reload();
          } else {
            this.passwordError = data?.message || 'Failed to remove the password.';
          }
        } catch (error) {
          this.passwordError = 'Network error. Please try again.';
          console.error('Password remove error:', error);
        } finally {
          this.passwordLoading = false;
          this.passwordRemoveConfirm = false;
        }
      },

      async tfaGetSecret() {
        this.tfaError = '';
        this.tfaLoading = true;

        try {
          const data = await this.authedPost('tfa/secret');

          if (data.secret) {
            this.tfaSecret = data.secret;
            this.tfaQrCode = data.qr_code;
          } else {
            this.tfaError = data?.message || 'Failed to start 2FA setup.';
          }
        } catch (error) {
          this.tfaError = 'Network error. Please try again.';
          console.error('2FA secret error:', error);
        } finally {
          this.tfaLoading = false;
        }
      },

      async tfaEnable() {
        this.tfaError = '';
        this.tfaLoading = true;

        try {
          const data = await this.authedPost('tfa/enable', {
            tfa_code: this.tfaCode
          });

          if (data.success) {
            // Recovery codes are only shown once; keep them on screen until reload.
            this.tfaRecoveryCodes = data.recovery_codes;
            this.tfaSecret = null;
            this.tfaQrCode = null;
            this.tfaCode = '';
          } else {
            this.tfaError = data?.message || 'Invalid code. Please try again.';
          }
        } catch (error) {
          this.tfaError = 'Network error. Please try again.';
          console.error('2FA enable error:', error);
        } finally {
          this.tfaLoading = false;
        }
      },

      async tfaDisable() {
        this.tfaError = '';
        this.tfaLoading = true;

        try {
          const data = await this.authedPost('tfa/disable', {
            tfa_code: this.tfaCode
          });

          if (data.success) {
            window.location.reload();
          } else {
            this.tfaError = data?.message || 'Invalid code. Please try again.';
          }
        } catch (error) {
          this.tfaError = 'Network error. Please try again.';
          console.error('2FA disable error:', error);
        } finally {
          this.tfaLoading = false;
        }
      }
    },

    appMaintenance: {
      modalIsOpen: false,
      modalPassword: '',
      modalError: '',
      modalLoading: false,
      
      modalOpen() {
        this.modalIsOpen = true;
        document.body.style.overflow = 'hidden';

        window.alpineApp.$nextTick(() => {
          window.alpineApp.$refs['appMaintenance.modalPasswordInput'].focus();
        });
      },

      modalClose() {
        this.modalIsOpen = false;
        
        setTimeout(() => {
          this.modalPassword = '';
          this.modalError = '';
        }, 300); // Transition

        document.body.style.overflow = 'auto';
      },

      async modalLogin() {
        this.modalError = '';
        this.modalOtpError = '';
        this.modalLoading = true;

        try {
          const response = await fetch('/maintenance', {
            method: 'POST',
            headers: {
              'Accept': 'application/json',
              'Content-Type': 'application/json',
            },
            credentials: 'same-origin',
            body: JSON.stringify({
              password: this.modalPassword,
            })
          });

          const data = await response.json();

          if (data.success) {
            window.location.href = '/';
          } else {
            this.modalError = data?.message || 'Failed to login. Please try again.';
            this.modalLoading = false;
          }
        } catch (error) {
          this.modalError = 'Network error. Please try again.';
          this.modalLoading = false;
        }
      },
    },

    init: function () {
      window.alpineApp = this;

      this.appScheme.init();
      this.appCurrency.init();
      this.appCart.init();
      this.appCustomer.init();
      this.appTickets.init();
    }
  }));

  // Product card hover gallery: pointer position picks the visible image.
  // Review card: shows the "Read more" toggle only when the clamped text actually
  // overflows. Re-measures on full page load (webfont swap can change line wrapping).
  Alpine.data('feedbackCard', () => ({
    expanded: false,
    clamped: false,

    init() {
      this.$nextTick(() => this.measure());
      window.addEventListener('load', () => this.measure(), { once: true });
    },

    measure() {
      if (this.expanded) return;
      this.clamped = [this.$refs.msg, this.$refs.reply].some((el) => el && el.scrollHeight > el.clientHeight + 1);
    },
  }));

  // Search modal: filters pre-rendered result rows by their data-search attribute.
  Alpine.data('searchModal', () => ({
    isOpen: false,
    term: '',
    visibleCount: 0,

    openModal() {
      this.isOpen = true;
      document.body.style.overflow = 'hidden';
      this.$nextTick(() => this.$refs.searchInput?.focus());
    },

    closeModal() {
      this.isOpen = false;
      document.body.style.removeProperty('overflow');
    },

    filter() {
      const term = this.term.trim().toLowerCase();
      let visible = 0;

      this.$root.querySelectorAll('[data-search]').forEach((el) => {
        const match = term !== '' && el.dataset.search.toLowerCase().includes(term);
        el.style.display = match && visible < 8 ? '' : 'none';
        if (match && visible < 8) visible++;
      });

      this.visibleCount = visible;
    },

    submit() {
      if (this.term.trim() !== '') {
        window.location.href = '/products?filters[keyword]=' + encodeURIComponent(this.term.trim());
      }
    },
  }));

  // Social proof: cycles through server-rendered recent-order cards one at a time.
  Alpine.data('socialProof', (count) => ({
    count,
    index: 0,
    visible: false,
    held: false,
    timer: null,

    init() {
      if (!this.count) return;

      try {
        if (sessionStorage.getItem('socialProofDismissed')) return;
      } catch (e) {
        // sessionStorage unavailable: keep showing
      }

      this.timer = setTimeout(() => this.show(), this.randomBetween(3000, 6000));
    },

    randomBetween(min, max) {
      return Math.floor(Math.random() * (max - min + 1)) + min;
    },

    show() {
      this.visible = true;
      this.timer = setTimeout(() => this.hide(), 7000);
    },

    hide() {
      if (this.held) return;

      this.visible = false;
      this.index++;

      if (this.index < this.count) {
        this.timer = setTimeout(() => this.show(), this.randomBetween(10000, 18000));
      }
    },

    hold() {
      this.held = true;
      clearTimeout(this.timer);
    },

    release() {
      if (!this.held) return;

      this.held = false;
      if (this.visible) this.timer = setTimeout(() => this.hide(), 2500);
    },

    dismiss() {
      clearTimeout(this.timer);
      this.visible = false;
      this.held = false;
      this.index = this.count;

      try {
        sessionStorage.setItem('socialProofDismissed', '1');
      } catch (e) {
        // ignore
      }
    },

    countryName(code) {
      try {
        return new Intl.DisplayNames(['en'], { type: 'region' }).of(code.toUpperCase()) || code;
      } catch (e) {
        return code;
      }
    },

    timeAgo(input) {
      const date = new Date(input);
      if (isNaN(date)) return '';

      const formatter = new Intl.RelativeTimeFormat('en');
      const ranges = {
        years: 3600 * 24 * 365,
        months: 3600 * 24 * 30,
        weeks: 3600 * 24 * 7,
        days: 3600 * 24,
        hours: 3600,
        minutes: 60,
      };

      const secondsElapsed = (date.getTime() - Date.now()) / 1000;

      for (const key in ranges) {
        if (ranges[key] < Math.abs(secondsElapsed)) {
          return formatter.format(Math.round(secondsElapsed / ranges[key]), key);
        }
      }

      return 'just now';
    },
  }));
});

// "On this page" rail and reading progress for blog posts and legal pages.
// Needs 4+ headings, and generates its own anchors because the editor emits
// headings without ids. The prose is the .editor next to the nav.
(function () {
  const toc = document.querySelector('.post-toc');
  if (!toc) return;

  const body = toc.parentElement ? toc.parentElement.querySelector('.editor') : null;
  const list = toc.querySelector('.post-toc-list');
  const box = toc.querySelector('.post-toc-scroll');
  const details = toc.querySelector('.post-toc-box');
  if (!body || !list || !details) return;

  const headings = body.querySelectorAll('h2, h3, .e-heading-h2, .e-heading-h3');
  if (headings.length < 4) return;

  // Sticky header height + breathing room; also the scroll-margin-top on .editor headings.
  const header = document.querySelector('.sa-header');
  const measure = () => {
    const sticky = header && getComputedStyle(header).position === 'sticky';
    const px = Math.ceil((sticky ? header.getBoundingClientRect().height : 0) + 24);
    document.documentElement.style.setProperty('--post-toc-offset', px + 'px');
    return px;
  };
  let OFFSET = measure();

  const taken = new Set();
  document.querySelectorAll('[id]').forEach((el) => taken.add(el.id));

  const slugify = (text) =>
    text
      .toLowerCase()
      .trim()
      .replace(/['’]/g, '')
      .replace(/[^\p{L}\p{N}]+/gu, '-')
      .replace(/^-+|-+$/g, '')
      .slice(0, 60);

  const uniqueId = (base) => {
    const stem = base || 'section';
    let id = stem;
    for (let n = 2; taken.has(id); n++) id = stem + '-' + n;
    taken.add(id);
    return id;
  };

  const wide = window.matchMedia('(min-width: 1280px)');
  const links = [];

  headings.forEach((h) => {
    const text = (h.textContent || '').trim();
    if (h.id) taken.add(h.id);
    else h.id = uniqueId(slugify(text));

    const li = document.createElement('li');
    const a = document.createElement('a');
    a.href = '#' + h.id;
    a.textContent = text;
    a.className = 'post-toc-link';
    li.appendChild(a);

    // h3s nest under the preceding h2; an h3 with no h2 before it stays top level.
    const parent = list.lastElementChild;
    const isSub = h.tagName === 'H3' || h.classList.contains('e-heading-h3');
    if (isSub && parent) {
      let nested = parent.querySelector(':scope > .post-toc-sublist');
      if (!nested) {
        nested = document.createElement('ol');
        nested.className = 'post-toc-sublist';
        parent.appendChild(nested);
      }
      nested.appendChild(li);
    } else {
      list.appendChild(li);
    }
    links.push(a);
  });

  let active = -1;
  let ticking = false;

  const update = () => {
    ticking = false;

    // Progress spans the post body, not the document.
    const rect = body.getBoundingClientRect();
    const span = Math.max(rect.height - (window.innerHeight - OFFSET), 1);
    const progress = Math.min(1, Math.max(0, (OFFSET - rect.top) / span));
    toc.style.setProperty('--post-progress', progress.toFixed(4));

    let i = 0;
    for (let n = 0; n < links.length; n++) {
      if (headings[n].getBoundingClientRect().top - OFFSET <= 1) i = n;
      else break;
    }
    if (progress > 0.995) i = links.length - 1;
    if (i === active) return;

    if (links[active]) {
      links[active].classList.remove('is-active');
      links[active].removeAttribute('aria-current');
    }
    active = i;
    links[i].classList.add('is-active');
    links[i].setAttribute('aria-current', 'true');

    if (box && box.scrollHeight > box.clientHeight + 1) {
      const ar = links[i].getBoundingClientRect();
      const br = box.getBoundingClientRect();
      if (ar.top < br.top || ar.bottom > br.bottom) {
        box.scrollTop += ar.top - br.top - (box.clientHeight - ar.height) / 2;
      }
    }
  };

  const onScroll = () => {
    if (ticking) return;
    ticking = true;
    requestAnimationFrame(update);
  };

  // The anchor itself scrolls and writes history; this only moves focus.
  list.addEventListener('click', (e) => {
    const a = e.target.closest('a[href^="#"]');
    if (!a) return;
    const target = document.getElementById(decodeURIComponent(a.hash.slice(1)));
    if (!target) return;
    target.setAttribute('tabindex', '-1');
    requestAnimationFrame(() => target.focus({ preventScroll: true }));
    if (!wide.matches) details.open = false;
  });

  // One box, two shapes: an inline disclosure below xl, an open rail from xl.
  const syncOpen = () => {
    details.open = wide.matches;
  };
  wide.addEventListener('change', syncOpen);
  syncOpen();

  window.addEventListener('scroll', onScroll, { passive: true });
  window.addEventListener('resize', () => { OFFSET = measure(); onScroll(); }, { passive: true });
  update();
  toc.classList.remove('hidden');
})();

// Visit-scoped campaign attribution sent with every checkout request (30-minute sliding window).
(() => {
  const KEY = 'attribution';
  const TTL = 30 * 60 * 1000;
  const UTM_KEYS = ['utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content'];
  const stripWww = host => host.toLowerCase().replace(/^www\./, '');

  const read = () => {
    try {
      const stored = JSON.parse(localStorage.getItem(KEY));
      return stored && stored.expires > Date.now() ? stored : null;
    } catch (e) {
      return null;
    }
  };

  const write = data => {
    try { localStorage.setItem(KEY, JSON.stringify({ ...data, expires: Date.now() + TTL })); } catch (e) {}
  };

  window.getAttribution = () => {
    const stored = read();
    if (!stored) return null;
    const { expires, ...attribution } = stored;
    return attribution;
  };

  const capture = () => {
    try {
      const params = new URLSearchParams(window.location.search);
      const utm = {};
      UTM_KEYS.forEach(key => {
        const value = params.get(key);
        if (value) utm[key] = value.slice(0, 100);
      });

      let referrerHost = null;
      if (document.referrer) {
        const host = stripWww(new URL(document.referrer).hostname);
        const own = stripWww(window.location.hostname);
        if (host && host !== own && host !== 'sellauth.com' && !host.endsWith('.sellauth.com')) referrerHost = host;
      }

      const existing = read();
      if (Object.keys(utm).length) {
        write(referrerHost ? { ...utm, referrer_host: referrerHost } : utm);
      } else if (existing) {
        write(window.getAttribution());
      } else if (referrerHost) {
        write({ referrer_host: referrerHost });
      }
    } catch (e) {}
  };

  if (!window.saConsent || window.saConsent.has('analytics')) {
    capture();
  } else {
    const stop = window.saConsent.onChange(state => {
      if (state.analytics) { stop(); capture(); }
    });
  }
})();
